#ifndef Definitions_H
#define Definitions_H

#define EXIT 14
#define MAX_LENGTH 21
#define PASSWORD_LENGTH 9
#define MAX_FEEDBACK_LENGTH 200
#define SELLER 0
#define BUYER 1
#define BUYER_AND_SELLER 2
#define NONE -1
#define testSize 5 

#endif // !Definitions_H