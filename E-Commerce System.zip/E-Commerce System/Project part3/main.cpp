#include "E-CommerceSystem.h"

int main()
{
	System system;
	system.systemRun();	
}